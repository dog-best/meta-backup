import BettingScreen from "@/components/Bills/betting/BettingScreen";
export default BettingScreen;
