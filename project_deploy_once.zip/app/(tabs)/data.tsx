import DataScreen from "@/components/Bills/data/DataScreen";
export default DataScreen;
