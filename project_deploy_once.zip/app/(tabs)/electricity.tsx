import ElectricityScreen from "@/components/Bills/electricity/ElectricityScreen";
export default ElectricityScreen;
