import { View, Text } from "react-native";

export default function CryptoToNgnCalculator() {
  return (
    <View>
      <Text>CryptoToNgnCalculator component</Text>
    </View>
  );
}
