import { View, Text } from "react-native";

export default function WalletList() {
  return (
    <View>
      <Text>WalletList component</Text>
    </View>
  );
}
