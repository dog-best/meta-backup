import { View, Text } from "react-native";

export default function BillServices() {
  return (
    <View>
      <Text>BillServices component</Text>
    </View>
  );
}
