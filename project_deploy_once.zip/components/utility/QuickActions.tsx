import { View, Text } from "react-native";

export default function QuickActions() {
  return (
    <View>
      <Text>QuickActions component</Text>
    </View>
  );
}
