import { View, Text } from "react-native";

export default function SectionHeader() {
  return (
    <View>
      <Text>SectionHeader component</Text>
    </View>
  );
}
