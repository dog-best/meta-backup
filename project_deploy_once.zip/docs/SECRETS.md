# Canonical Secret / Env Variable Names (use THESE)

You currently have duplicates like `SB_URL` and `SUPABASE_URL`.
**Ignore the `SB_*` names.** The codebase is standardized on the names below.

## 1) Expo App (client) — put in `.env` at project root
These are **public** (anon key is safe to ship in the app).

- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_ANON_KEY`

Example:

```bash
EXPO_PUBLIC_SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co"
EXPO_PUBLIC_SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"
```

## 2) Supabase Edge Functions — set via Dashboard or CLI secrets
These are **server-side** secrets.

### Required (functions will break without these)
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` (used by some functions when they need to validate user JWT)
- `SUPABASE_SERVICE_ROLE_KEY` (server authority; never put this in the app)

### Fintech (Paystack)
- `PAYSTACK_SECRET_KEY`

### Crypto (only if using these flows)
- `EVM_WALLET_MNEMONIC` (EVM wallet generation)
- `SOLANA_WALLET_SECRET` (Solana wallet generation)
- `INFURA_PROJECT_ID` (if using Infura RPC)
- `ALCHEMY_WEBHOOK_ID` (if receiving Alchemy webhooks)
- `ALCHEMY_AUTH_TOKEN` (for validating webhook signatures)

## CLI examples

```bash
supabase secrets set SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co"
supabase secrets set SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"
supabase secrets set SUPABASE_SERVICE_ROLE_KEY="YOUR_SERVICE_ROLE_KEY"

supabase secrets set PAYSTACK_SECRET_KEY="sk_live_or_test_..."

# Optional crypto
supabase secrets set EVM_WALLET_MNEMONIC="..."
supabase secrets set SOLANA_WALLET_SECRET="..."
supabase secrets set INFURA_PROJECT_ID="..."
supabase secrets set ALCHEMY_WEBHOOK_ID="..."
supabase secrets set ALCHEMY_AUTH_TOKEN="..."
```

## What to do with the existing `SB_*` entries
You can delete them later. They are not used by this code.
