// hooks/wallet/useWallet.ts
import { useAuth } from "@/hooks/authenication/useAuth";
import { supabase } from "@/supabase/client";
import { useCallback, useEffect, useState } from "react";

type WalletBalanceRow = {
  account_id: string;
  user_id: string;
  balance: number | string | null;
  last_activity_at: string | null;
};

type WalletBalance = {
  account_id: string;
  balance: number;
  last_activity_at: string | null;
};

export function useWallet() {
  const { user } = useAuth();

  const [wallet, setWallet] = useState<WalletBalance | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWallet = useCallback(async () => {
    if (!user) {
      setWallet(null);
      setError(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Ensure the user's NGN wallet ledger account exists (covers projects missing the auth trigger).
      // This is safe/idempotent.
      await supabase.rpc("ensure_user_wallet_account");

      const { data, error } = await supabase
        .from("wallet_balances")
        .select("account_id, user_id, balance, last_activity_at")
        .eq("user_id", user.id)
        .maybeSingle<WalletBalanceRow>();

      if (error) throw error;

      if (!data) {
        // Not an error: user may be new and has no ledger activity yet.
        setWallet({ account_id: "", balance: 0, last_activity_at: null });
      } else {
        const balanceNum =
          typeof data.balance === "string"
            ? Number(data.balance)
            : typeof data.balance === "number"
              ? data.balance
              : 0;

        setWallet({
          account_id: data.account_id ?? "",
          balance: Number.isFinite(balanceNum) ? balanceNum : 0,
          last_activity_at: data.last_activity_at ?? null,
        });
      }
    } catch (e: any) {
      console.error("Wallet fetch error:", e);
      setError("Failed to load wallet balance");
      setWallet(null);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // initial load
  useEffect(() => {
    fetchWallet();
  }, [fetchWallet]);

  // 🔔 Realtime: listen to ledger changes for this account and refresh balance
  useEffect(() => {
    if (!user || !wallet?.account_id) return;

    const channel = supabase
      .channel(`wallet-ledger-${wallet.account_id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "ledger_entries",
          filter: `account_id=eq.${wallet.account_id}`,
        },
        () => {
          fetchWallet();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, wallet?.account_id, fetchWallet]);

  return {
    wallet,
    balance: wallet?.balance ?? 0,
    loading,
    error,
    refetch: fetchWallet,
  };
}
