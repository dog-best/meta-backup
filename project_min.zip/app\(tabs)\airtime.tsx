import AirtimeScreen from "@/components/Bills/airtime/AirtimeScreen";
export default AirtimeScreen;
