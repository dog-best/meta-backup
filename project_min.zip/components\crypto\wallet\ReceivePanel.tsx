import { View, Text } from "react-native";

export default function ReceivePanel() {
  return (
    <View>
      <Text>ReceivePanel component</Text>
    </View>
  );
}
