import { View, Text } from "react-native";

export default function BillPaymentForm() {
  return (
    <View>
      <Text>BillPaymentForm component</Text>
    </View>
  );
}
