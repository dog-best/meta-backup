import { View, Text } from "react-native";

export default function NgnBalanceCard() {
  return (
    <View>
      <Text>NgnBalanceCard component</Text>
    </View>
  );
}
