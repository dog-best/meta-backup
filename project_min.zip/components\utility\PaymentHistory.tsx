import { View, Text } from "react-native";

export default function PaymentHistory() {
  return (
    <View>
      <Text>PaymentHistory component</Text>
    </View>
  );
}
